<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response ;

// Now we need some classes in our Controller because we need that in our form (for the inputs that we will create)
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

use App\Entity\Events ;

class EventsController extends AbstractController
{
    
    /**
    * @Route("/", name="home_page")
    */
   public function showAction()
   {
       // Here we will use getDoctrine to use doctrine and we will select the entity that we want to work with and we used findAll() to bring all the information from it and we will save it inside a variable named todos and the type of the result will be an array 
       $events = $this->getDoctrine()->getRepository('App:Events')->findAll();
      
       return $this->render('events/index.html.twig', array('events'=>$events));
// we send the result (the variable that have the result of bringing all info from our database) to the index.html.twig page
   }
   
   
   //------CREATE------//
   
    /**
    * @Route("/create", name="create_page")
    */
   public function createAction(Request $request)
   {
       // Here we create an object from the class that we made 
       $events = new Events;
/* Here we will build a form using createFormBuilder and inside this function we will put our object and then we write add then we select the input type then an array to add an attribute that we want in our input field */
       $form = $this->createFormBuilder($events)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('img', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('datetime', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
   ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn btn-success border border-dark', 'style'=>'margin-bottom:15px')))
       ->getForm();
       $form->handleRequest($request);
       

       /* Here we have an if statement, if we click submit and if  the form is valid we will take the values from the form and we will save them in the new variables */
       if($form->isSubmitted() && $form->isValid()){
           //fetching data

           // taking the data from the inputs by the name of the inputs then getData() function
           $img = $form['img']->getData();
           $name = $form['name']->getData();
           $url = $form['url']->getData();
           $capacity = $form['capacity']->getData();
           $description = $form['description']->getData();
           $address = $form['address']->getData();
           $phone = $form['phone']->getData();
           $email = $form['email']->getData();
           $type = $form['type']->getData();
           $datetime = $form['datetime']->getData();
           
           // Here we will get the current date
           

/* these functions we bring from our entities, every column have a set function and we put the value that we get from the form */
           $events->setImg($img);
           $events->setName($name);
           $events->setUrl($url);
           $events->setCapacity($capacity);
           $events->setDescription($description);
           $events->setAddress($address);
           $events->setPhone($phone);
           $events->setEmail($email);
           $events->setType($type);
           $events->setDatetime($datetime);
          
           $em = $this->getDoctrine()->getManager();
           $em->persist($events);
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Events Added'
                   );
           return $this->redirectToRoute('home_page');
       }
/* now to make the form we will add this line form->createView() and now you can see the form in create.html.twig file  */
       return $this->render('events/create.html.twig', array('form' => $form->createView()));
   }
   
   //------DETAILS------//
    
   
   /**
    * @Route("/details/{id}", name="details_page")
    */
   public function detailsAction($id)
   {
       $events = $this->getDoctrine()->getRepository('App:Events')->find($id);
       return $this->render('events/details.html.twig', array('events' => $events));
   }
   
   
   //------EDIT------//
    
   
   /**
    * @Route("/edit/{id}", name="events_edit")
    */
   public function editAction( $id, Request $request){
/* Here we have a variable todo and it will save the result of this search and it will be one result because we search based on a specific id */
   $events = $this->getDoctrine()->getRepository('App:Events')->find($id);

/* Now we will use set functions and inside this set functions we will bring the value that is already exist using get function for example we have setName() and inside it we will bring the current value and use it again */
            $events->setName($events->getName());
            $events->setImg($events->getImg());
            $events->setDatetime($events->getDatetime());
            $events->setDescription($events->getDescription());
            $events->setCapacity($events->getCapacity());
            $events->setEmail($events->getEmail());
            $events->setPhone($events->getPhone());
            $events->setAddress($events->getAddress());
            $events->setUrl($events->getUrl());
            $events->setType($events->getType());
 
/* Now when you type createFormBuilder and you will put the variable todo the form will be filled of the data that you already set it */
       $form = $this->createFormBuilder($events)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('img', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('capacity', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('email', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('phone', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('url', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('type', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('datetime', DateTimeType::class, array('attr' => array('style'=>'margin:0 0 10px 0')))
   ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn btn-success border border-dark', 'style'=>'margin:20px 0 10px 0')))
       ->getForm();
       $form->handleRequest($request);
       if($form->isSubmitted() && $form->isValid()){
           //fetching data
           $img = $form['img']->getData();
           $name = $form['name']->getData();
           $description = $form['description']->getData();
           $capacity = $form['capacity']->getData();
           $email = $form['email']->getData();
           $phone = $form['phone']->getData();
           $address = $form['address']->getData();
           $url = $form['url']->getData();
           $type = $form['type']->getData();
           $datetime = $form['datetime']->getData();
           
           $em = $this->getDoctrine()->getManager();
           $events = $em->getRepository('App:Events')->find($id);
           $events->setImg($img);
           $events->setName($name);
           $events->setDescription($description);
           $events->setCapacity($capacity);
           $events->setEmail($email);
           $events->setPhone($phone);
           $events->setAddress($address);
           $events->setUrl($url);
           $events->setType($type);
           $events->setDatetime($datetime);
          
        
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Events Updated'
                   );
           return $this->redirectToRoute('home_page');
       }
       return $this->render('events/edit.html.twig', array('events' => $events, 'form' => $form->createView()));
   }
   
   
   //------DELETE------//

 /**
    * @Route("/delete/{id}", name="travels_delete")
    */
   public function deleteAction($id){
                $em = $this->getDoctrine()->getManager();
                
           $travels = $em->getRepository('App:Events')->find($id);
           $em->remove($travels);
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Events Removed'
                   );
            return $this->redirectToRoute('home_page');
   }
}
