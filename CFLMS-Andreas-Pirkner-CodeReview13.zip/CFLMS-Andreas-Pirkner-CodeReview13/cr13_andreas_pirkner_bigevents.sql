-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 07. Aug 2020 um 15:18
-- Server-Version: 10.4.13-MariaDB
-- PHP-Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `cr13_andreas_pirkner_bigevents`
--
CREATE DATABASE IF NOT EXISTS `cr13_andreas_pirkner_bigevents` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cr13_andreas_pirkner_bigevents`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `events`
--

CREATE TABLE `events` (
  `id` int(10) NOT NULL,
  `name` varchar(20) CHARACTER SET utf8 NOT NULL,
  `datetime` datetime NOT NULL,
  `description` varchar(250) CHARACTER SET utf8 NOT NULL,
  `img` varchar(50) CHARACTER SET utf8 NOT NULL,
  `capacity` int(10) NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(50) CHARACTER SET utf8 NOT NULL,
  `address` varchar(100) CHARACTER SET utf8 NOT NULL,
  `url` varchar(100) CHARACTER SET utf8 NOT NULL,
  `type` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `events`
--

INSERT INTO `events` (`id`, `name`, `datetime`, `description`, `img`, `capacity`, `email`, `phone`, `address`, `url`, `type`) VALUES
(1, 'Event 1', '2020-08-16 09:03:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sit amet tempor lorem. Proin egestas sagittis orci sit amet ultricies. Etiam nec pharetra justo, scelerisque scelerisque elit.', 'img/event1.jpg', 1000, 'andreas.pirkner@gmx.net', '+43112345678', 'Praterstraße 31, 1020 Wien', 'http://pirkner.codefactory.live/', 'Music'),
(2, 'Event 2', '2020-08-17 09:03:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sit amet tempor lorem. Proin egestas sagittis orci sit amet ultricies. Etiam nec pharetra justo, scelerisque scelerisque elit.', 'img/event2.jpg', 2000, 'andreas.pirkner@gmx.net', '+4317654321', 'Meidlinger Hauptstraße 26, 1120 Wien', 'http://pirkner.codefactory.live/', 'Music'),
(4, 'Event 3', '2020-09-01 05:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sit amet tempor lorem. Proin egestas sagittis orci sit amet ultricies. Etiam nec pharetra justo, scelerisque scelerisque elit.', 'img/event3.jpg', 3000, 'andreas.pirkner@gmx.net', '+4318475609', 'Eichenstrasse 25, 1120 Wien', 'http://pirkner.codefactory.live/', 'Music'),
(5, 'Event 4', '2020-10-11 14:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sit amet tempor lorem. Proin egestas sagittis orci sit amet ultricies. Etiam nec pharetra justo, scelerisque scelerisque elit.', 'img/event4.jpg', 4000, 'andreas.pirkner@gmx.net', '+4313904567', 'Ottakringerstraße 78, 1160 Wien', 'http://pirkner.codefactory.live/', 'Music'),
(6, 'Event 5', '2020-11-19 18:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sit amet tempor lorem. Proin egestas sagittis orci sit amet ultricies. Etiam nec pharetra justo, scelerisque scelerisque elit.', 'img/event5.jpg', 5000, 'andreas.pirkner@gmx.net', '+43138279045', 'Hernalser Hauptstraße 112, 1170 Wien', 'http://pirkner.codefactory.live/', 'Music'),
(7, 'Event 6', '2020-11-26 19:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sit amet tempor lorem. Proin egestas sagittis orci sit amet ultricies. Etiam nec pharetra justo, scelerisque scelerisque elit.', 'img/event6.jpg', 6000, 'andreas.pirkner@gmx.net', '+43198456378', 'Währinger Straße 87, 1180 Wien', 'http://pirkner.codefactory.live/', 'Music'),
(8, 'Event 7', '2020-12-11 21:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sit amet tempor lorem. Proin egestas sagittis orci sit amet ultricies. Etiam nec pharetra justo, scelerisque scelerisque elit.', 'img/event7.jpg', 7000, 'andreas.pirkner@gmx.net', '+43137464590', 'Alserstraße 67, 1090 Wien', 'http://pirkner.codefactory.live/', 'Music');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `events`
--
ALTER TABLE `events`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
